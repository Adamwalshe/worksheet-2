﻿namespace Q9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}